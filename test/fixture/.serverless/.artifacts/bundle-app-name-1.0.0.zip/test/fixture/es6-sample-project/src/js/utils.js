/**
 * @module utils
 * All the helper functions needed in this project
 */
export default {
  /**
   * @param {String} id Either '#some' or 'some'.
   * @returns {HTMLElement}
   */
  $(id) {
    id = id[0] === '#' ? id.substr(1, id.length) : id;
    return document.getElementById(id);
  },
  /**
   * @param {String|Element} element
   * @returns A DOM object, such as HTMLElement, Window, and Document.
   */
  evaluate(element) {
    let el;
    switch (this.toType(element)) {
      case 'window':
      case 'htmldocument':
      case 'element':
        el = element;
        break;
      case 'string':
        el = this.$(element);
        break;
      default:
        console.warn('Unknown type!');
    }
    this.assert(el, 'Can\'t evaluate: @param ' + element);
    return el;
  },
  /**
   * @param {Object|Element|String} obj
   * @returns {String}
   */
  toType(obj) {
    if (obj === window && obj.document && obj.location) {
      return 'window';
    } else if (obj === document) {
      return 'htmldocument';
    } else if (typeof obj === 'string') {
      return 'string';
    } else if (this.isElement(obj)) {
      return 'element';
    }
  },
  /**
   * @param {Element} el
   * @returns {Boolean}
   */
  isElement(el) {
    // DOM, Level2
    if ('HTMLElement' in window) {
      return !!el && el instanceof HTMLElement;
    }
    // Older browsers
    return !!el && typeof el === 'object' && el.nodeType === 1 && !!el.nodeName;
  },
  /**
   * @param {String} html
   * @returns {Element}
   */
  createFragment(html) {
    const frag = document.createDocumentFragment();
    const temp = document.createElement('div');

    temp.innerHTML = html;
    while (temp.firstChild) {
      frag.appendChild(temp.firstChild);
    }
    return frag;
  },
  /**
   * Checks if the condition evaluates to true.
   * @param {T} condition The condition to check.
   * @param {string=} message Error message in case of failure.
   * @throws {Error} When the condition evaluates to false.
   */
  assert(condition, message = 'Assertion failed') {
    if (!condition) {
      if (typeof Error !== 'undefined') {
        throw new Error(message);
      }
      throw message; // Fallback
    }
  }
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlc3QvZml4dHVyZS9lczYtc2FtcGxlLXByb2plY3Qvc3JjL2pzL3V0aWxzLmpzIl0sIm5hbWVzIjpbIiQiLCJpZCIsInN1YnN0ciIsImxlbmd0aCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJldmFsdWF0ZSIsImVsZW1lbnQiLCJlbCIsInRvVHlwZSIsImNvbnNvbGUiLCJ3YXJuIiwiYXNzZXJ0Iiwib2JqIiwid2luZG93IiwibG9jYXRpb24iLCJpc0VsZW1lbnQiLCJIVE1MRWxlbWVudCIsIm5vZGVUeXBlIiwibm9kZU5hbWUiLCJjcmVhdGVGcmFnbWVudCIsImh0bWwiLCJmcmFnIiwiY3JlYXRlRG9jdW1lbnRGcmFnbWVudCIsInRlbXAiLCJjcmVhdGVFbGVtZW50IiwiaW5uZXJIVE1MIiwiZmlyc3RDaGlsZCIsImFwcGVuZENoaWxkIiwiY29uZGl0aW9uIiwibWVzc2FnZSIsIkVycm9yIl0sIm1hcHBpbmdzIjoiQUFBQTs7OztBQUlBLGVBQWU7QUFDYjs7OztBQUlBQSxJQUFFQyxFQUFGLEVBQU07QUFDSkEsU0FBTUEsR0FBRyxDQUFILE1BQVUsR0FBWCxHQUFrQkEsR0FBR0MsTUFBSCxDQUFVLENBQVYsRUFBYUQsR0FBR0UsTUFBaEIsQ0FBbEIsR0FBNENGLEVBQWpEO0FBQ0EsV0FBT0csU0FBU0MsY0FBVCxDQUF3QkosRUFBeEIsQ0FBUDtBQUNELEdBUlk7QUFTYjs7OztBQUlBSyxXQUFTQyxPQUFULEVBQWtCO0FBQ2hCLFFBQUlDLEVBQUo7QUFDQSxZQUFRLEtBQUtDLE1BQUwsQ0FBWUYsT0FBWixDQUFSO0FBQ0UsV0FBSyxRQUFMO0FBQ0EsV0FBSyxjQUFMO0FBQ0EsV0FBSyxTQUFMO0FBQ0VDLGFBQUtELE9BQUw7QUFDQTtBQUNGLFdBQUssUUFBTDtBQUNFQyxhQUFLLEtBQUtSLENBQUwsQ0FBT08sT0FBUCxDQUFMO0FBQ0E7QUFDRjtBQUNFRyxnQkFBUUMsSUFBUixDQUFhLGVBQWI7QUFWSjtBQVlBLFNBQUtDLE1BQUwsQ0FBWUosRUFBWixFQUFnQiw2QkFBNkJELE9BQTdDO0FBQ0EsV0FBT0MsRUFBUDtBQUNELEdBN0JZO0FBOEJiOzs7O0FBSUFDLFNBQU9JLEdBQVAsRUFBWTtBQUNWLFFBQUlBLFFBQVFDLE1BQVIsSUFBa0JELElBQUlULFFBQXRCLElBQWtDUyxJQUFJRSxRQUExQyxFQUFvRDtBQUNsRCxhQUFPLFFBQVA7QUFDRCxLQUZELE1BRU8sSUFBSUYsUUFBUVQsUUFBWixFQUFzQjtBQUMzQixhQUFPLGNBQVA7QUFDRCxLQUZNLE1BRUEsSUFBSSxPQUFPUyxHQUFQLEtBQWUsUUFBbkIsRUFBNkI7QUFDbEMsYUFBTyxRQUFQO0FBQ0QsS0FGTSxNQUVBLElBQUksS0FBS0csU0FBTCxDQUFlSCxHQUFmLENBQUosRUFBeUI7QUFDOUIsYUFBTyxTQUFQO0FBQ0Q7QUFDRixHQTVDWTtBQTZDYjs7OztBQUlBRyxZQUFVUixFQUFWLEVBQWM7QUFDWjtBQUNBLFFBQUksaUJBQWlCTSxNQUFyQixFQUE2QjtBQUMzQixhQUFRLENBQUMsQ0FBQ04sRUFBRixJQUFRQSxjQUFjUyxXQUE5QjtBQUNEO0FBQ0Q7QUFDQSxXQUFRLENBQUMsQ0FBQ1QsRUFBRixJQUFRLE9BQU9BLEVBQVAsS0FBYyxRQUF0QixJQUFrQ0EsR0FBR1UsUUFBSCxLQUFnQixDQUFsRCxJQUNKLENBQUMsQ0FBQ1YsR0FBR1csUUFEVDtBQUVELEdBekRZO0FBMERiOzs7O0FBSUFDLGlCQUFlQyxJQUFmLEVBQXFCO0FBQ25CLFVBQU1DLE9BQU9sQixTQUFTbUIsc0JBQVQsRUFBYjtBQUNBLFVBQU1DLE9BQU9wQixTQUFTcUIsYUFBVCxDQUF1QixLQUF2QixDQUFiOztBQUVBRCxTQUFLRSxTQUFMLEdBQWlCTCxJQUFqQjtBQUNBLFdBQU9HLEtBQUtHLFVBQVosRUFBd0I7QUFDdEJMLFdBQUtNLFdBQUwsQ0FBaUJKLEtBQUtHLFVBQXRCO0FBQ0Q7QUFDRCxXQUFPTCxJQUFQO0FBQ0QsR0F2RVk7QUF3RWI7Ozs7OztBQU1BVixTQUFPaUIsU0FBUCxFQUFrQkMsVUFBVSxrQkFBNUIsRUFBZ0Q7QUFDOUMsUUFBSSxDQUFDRCxTQUFMLEVBQWdCO0FBQ2QsVUFBSSxPQUFPRSxLQUFQLEtBQWlCLFdBQXJCLEVBQWtDO0FBQ2hDLGNBQU0sSUFBSUEsS0FBSixDQUFVRCxPQUFWLENBQU47QUFDRDtBQUNELFlBQU1BLE9BQU4sQ0FKYyxDQUlDO0FBQ2hCO0FBQ0Y7QUFyRlksQ0FBZiIsImZpbGUiOiJ0ZXN0L2ZpeHR1cmUvZXM2LXNhbXBsZS1wcm9qZWN0L3NyYy9qcy91dGlscy5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQG1vZHVsZSB1dGlsc1xuICogQWxsIHRoZSBoZWxwZXIgZnVuY3Rpb25zIG5lZWRlZCBpbiB0aGlzIHByb2plY3RcbiAqL1xuZXhwb3J0IGRlZmF1bHQge1xuICAvKipcbiAgICogQHBhcmFtIHtTdHJpbmd9IGlkIEVpdGhlciAnI3NvbWUnIG9yICdzb21lJy5cbiAgICogQHJldHVybnMge0hUTUxFbGVtZW50fVxuICAgKi9cbiAgJChpZCkge1xuICAgIGlkID0gKGlkWzBdID09PSAnIycpID8gaWQuc3Vic3RyKDEsIGlkLmxlbmd0aCkgOiBpZDtcbiAgICByZXR1cm4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xuICB9LFxuICAvKipcbiAgICogQHBhcmFtIHtTdHJpbmd8RWxlbWVudH0gZWxlbWVudFxuICAgKiBAcmV0dXJucyBBIERPTSBvYmplY3QsIHN1Y2ggYXMgSFRNTEVsZW1lbnQsIFdpbmRvdywgYW5kIERvY3VtZW50LlxuICAgKi9cbiAgZXZhbHVhdGUoZWxlbWVudCkge1xuICAgIGxldCBlbDtcbiAgICBzd2l0Y2ggKHRoaXMudG9UeXBlKGVsZW1lbnQpKSB7XG4gICAgICBjYXNlICd3aW5kb3cnOlxuICAgICAgY2FzZSAnaHRtbGRvY3VtZW50JzpcbiAgICAgIGNhc2UgJ2VsZW1lbnQnOlxuICAgICAgICBlbCA9IGVsZW1lbnQ7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnc3RyaW5nJzpcbiAgICAgICAgZWwgPSB0aGlzLiQoZWxlbWVudCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgY29uc29sZS53YXJuKCdVbmtub3duIHR5cGUhJyk7XG4gICAgfVxuICAgIHRoaXMuYXNzZXJ0KGVsLCAnQ2FuXFwndCBldmFsdWF0ZTogQHBhcmFtICcgKyBlbGVtZW50KTtcbiAgICByZXR1cm4gZWw7XG4gIH0sXG4gIC8qKlxuICAgKiBAcGFyYW0ge09iamVjdHxFbGVtZW50fFN0cmluZ30gb2JqXG4gICAqIEByZXR1cm5zIHtTdHJpbmd9XG4gICAqL1xuICB0b1R5cGUob2JqKSB7XG4gICAgaWYgKG9iaiA9PT0gd2luZG93ICYmIG9iai5kb2N1bWVudCAmJiBvYmoubG9jYXRpb24pIHtcbiAgICAgIHJldHVybiAnd2luZG93JztcbiAgICB9IGVsc2UgaWYgKG9iaiA9PT0gZG9jdW1lbnQpIHtcbiAgICAgIHJldHVybiAnaHRtbGRvY3VtZW50JztcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBvYmogPT09ICdzdHJpbmcnKSB7XG4gICAgICByZXR1cm4gJ3N0cmluZyc7XG4gICAgfSBlbHNlIGlmICh0aGlzLmlzRWxlbWVudChvYmopKSB7XG4gICAgICByZXR1cm4gJ2VsZW1lbnQnO1xuICAgIH1cbiAgfSxcbiAgLyoqXG4gICAqIEBwYXJhbSB7RWxlbWVudH0gZWxcbiAgICogQHJldHVybnMge0Jvb2xlYW59XG4gICAqL1xuICBpc0VsZW1lbnQoZWwpIHtcbiAgICAvLyBET00sIExldmVsMlxuICAgIGlmICgnSFRNTEVsZW1lbnQnIGluIHdpbmRvdykge1xuICAgICAgcmV0dXJuICghIWVsICYmIGVsIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQpO1xuICAgIH1cbiAgICAvLyBPbGRlciBicm93c2Vyc1xuICAgIHJldHVybiAoISFlbCAmJiB0eXBlb2YgZWwgPT09ICdvYmplY3QnICYmIGVsLm5vZGVUeXBlID09PSAxICYmXG4gICAgICAgICEhZWwubm9kZU5hbWUpO1xuICB9LFxuICAvKipcbiAgICogQHBhcmFtIHtTdHJpbmd9IGh0bWxcbiAgICogQHJldHVybnMge0VsZW1lbnR9XG4gICAqL1xuICBjcmVhdGVGcmFnbWVudChodG1sKSB7XG4gICAgY29uc3QgZnJhZyA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKTtcbiAgICBjb25zdCB0ZW1wID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG5cbiAgICB0ZW1wLmlubmVySFRNTCA9IGh0bWw7XG4gICAgd2hpbGUgKHRlbXAuZmlyc3RDaGlsZCkge1xuICAgICAgZnJhZy5hcHBlbmRDaGlsZCh0ZW1wLmZpcnN0Q2hpbGQpO1xuICAgIH1cbiAgICByZXR1cm4gZnJhZztcbiAgfSxcbiAgLyoqXG4gICAqIENoZWNrcyBpZiB0aGUgY29uZGl0aW9uIGV2YWx1YXRlcyB0byB0cnVlLlxuICAgKiBAcGFyYW0ge1R9IGNvbmRpdGlvbiBUaGUgY29uZGl0aW9uIHRvIGNoZWNrLlxuICAgKiBAcGFyYW0ge3N0cmluZz19IG1lc3NhZ2UgRXJyb3IgbWVzc2FnZSBpbiBjYXNlIG9mIGZhaWx1cmUuXG4gICAqIEB0aHJvd3Mge0Vycm9yfSBXaGVuIHRoZSBjb25kaXRpb24gZXZhbHVhdGVzIHRvIGZhbHNlLlxuICAgKi9cbiAgYXNzZXJ0KGNvbmRpdGlvbiwgbWVzc2FnZSA9ICdBc3NlcnRpb24gZmFpbGVkJykge1xuICAgIGlmICghY29uZGl0aW9uKSB7XG4gICAgICBpZiAodHlwZW9mIEVycm9yICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBtZXNzYWdlOyAvLyBGYWxsYmFja1xuICAgIH1cbiAgfVxufTtcbiJdfQ==